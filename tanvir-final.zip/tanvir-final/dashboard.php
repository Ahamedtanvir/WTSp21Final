<html>
<head>
 
</head>
<body>
<h1> Dashboard</h1>
<hr>
<a href="reg.php"> Registration</a> <br><br>
<a href="editinfo.php">Info</a><br><br>
<a href="delete.php">Delete</a><br><br>
<a href="show.php">Show</a><br><br>

</body>
</html>